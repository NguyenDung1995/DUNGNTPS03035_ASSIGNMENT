<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<body bgcolor="#FFFFCC">
<?php
echo '<h3>Kích vào chữ: Mua sách này để chọn mua mặt hàng</br>';
echo 'Nhập số lượng mỗi mặt hàng cần mua, rồi nhấn nút cập nhật</br>';
echo 'Tìm kiếm theo tên sách hoặc tác giả rồi mua hàng</br>';
echo 'Nhấn thanh toán để xác nhận hóa đơn mua hàng. Hóa đơn sẽ được lưu. Hàng sẽ được chuyển đến địa chỉ của bạn trong tài khoản đăng ký thành viên';
echo '<p align=center><b><A Href="index.php">Về trang chủ</A></b></p>';
?>
</body>