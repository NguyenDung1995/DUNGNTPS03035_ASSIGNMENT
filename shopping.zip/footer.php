<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<Table border="0" Cellspacing="0" Cellpadding="5" Width="100%">
	<Tr>
		<Td align="center" style="color: #FFFFFF">
			<strong> Copyright 2010 - BOOKs SHOPPING <BR>
			CẦU GIẤY - HÀ NỘI</strong> </Td>
	</Tr>
</Table